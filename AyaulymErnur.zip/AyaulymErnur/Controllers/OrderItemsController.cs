﻿using ProjectX.Models;
using ProjectX.Repos;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace ProjectX.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class OrderItemsController : ControllerBase
    {
        private readonly IOrderItemsRepository _orderItemsRepository;
        public OrderItemsController(IOrderItemsRepository todosRepository)
        {
            _orderItemsRepository = todosRepository;
        }


        [HttpGet]
        [Route("get-all")]
        public async Task<IActionResult> GetAllAsync()
        {
            var result = await _orderItemsRepository.GetAllAsync();
            return Ok(result);
        }

        [HttpGet]
        [Route("get-by-id")]
        public async Task<IActionResult> GetItemByIdAsync(int id)
        {
            var result = await _orderItemsRepository.GetByIdAsync(id);
            return Ok(result);
        }

        [HttpPost]
        [Route("save")]
        public async Task<IActionResult> SaveAsync(OrderItems newTodo)
        {
            var result = await _orderItemsRepository.SaveAsync(newTodo);
            return Ok(result);
        }

        [HttpPost]
        [Route("update")]
        public async Task<IActionResult> UpdateAsync(OrderItems updateTodo)
        {
            var result = await _orderItemsRepository.UpdateAsync(updateTodo);
            return Ok(result);
        }

        [HttpDelete]
        [Route("delete")]
        public async Task<IActionResult> DeleteAsync(int id)
        {
            var result = await _orderItemsRepository.DeleteAsync(id);
            return Ok(result);
        }
    }
}