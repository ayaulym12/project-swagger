﻿using ProjectX.Models;
using ProjectX.Repos;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace ProjectX.Controllers
{
    //[Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private readonly IOrdersRepository _ordersRepository;
        public OrdersController(IOrdersRepository todosRepository)
        {
            _ordersRepository = todosRepository;
        }


        [HttpGet]
        [Route("get-all")]
        public async Task<IActionResult> GetAllAsync()
        {
            var result = await _ordersRepository.GetAllAsync();
            return Ok(result);
        }

        [HttpGet]
        [Route("get-by-id")]
        public async Task<IActionResult> GetItemByIdAsync(int id)
        {
            var result = await _ordersRepository.GetByIdAsync(id);
            return Ok(result);
        }

        [HttpPost]
        [Route("save")]
        public async Task<IActionResult> SaveAsync(Orders newTodo)
        {
            var result = await _ordersRepository.SaveAsync(newTodo);
            return Ok(result);
        }

        [HttpPost]
        [Route("update")]
        public async Task<IActionResult> UpdateAsync(Orders updateTodo)
        {
            var result = await _ordersRepository.UpdateAsync(updateTodo);
            return Ok(result);
        }

        [HttpDelete]
        [Route("delete")]
        public async Task<IActionResult> DeleteAsync(int id)
        {
            var result = await _ordersRepository.DeleteAsync(id);
            return Ok(result);
        }
    }
}