﻿using ProjectX.Models;
using ProjectX.Repos;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace ProjectX.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ItemsController : ControllerBase
    {
        private readonly IItemsRepository _itemsRepository;
        public ItemsController(IItemsRepository todosRepository)
        {
            _itemsRepository = todosRepository;
        }


        [HttpGet]
        [Route("get-all")]
        public async Task<IActionResult> GetAllAsync()
        {
            var result = await _itemsRepository.GetAllAsync();
            return Ok(result);
        }

        [HttpGet]
        [Route("get-by-id")]
        public async Task<IActionResult> GetItemByIdAsync(int id)
        {
            var result = await _itemsRepository.GetByIdAsync(id);
            return Ok(result);
        }

        [HttpPost]
        [Route("save")]
        public async Task<IActionResult> SaveAsync(Items newTodo)
        {
            var result = await _itemsRepository.SaveAsync(newTodo);
            return Ok(result);
        }

        [HttpPost]
        [Route("update")]
        public async Task<IActionResult> UpdateAsync(Items updateTodo)
        {
            var result = await _itemsRepository.UpdateAsync(updateTodo);
            return Ok(result);
        }

        [HttpDelete]
        [Route("delete")]
        public async Task<IActionResult> DeleteAsync(int id)
        {
            var result = await _itemsRepository.DeleteAsync(id);
            return Ok(result);
        }
    }
}