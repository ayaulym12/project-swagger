﻿using ProjectX.Models;
using ProjectX.Repos;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace ProjectX.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUsersRepository _usersRepository;
        public UsersController(IUsersRepository todosRepository)
        {
            _usersRepository = todosRepository;
        }


        [HttpGet]
        [Route("get-all")]
        public async Task<IActionResult> GetAllAsync()
        {
            var result = await _usersRepository.GetAllAsync();
            return Ok(result);
        }

        [HttpGet]
        [Route("get-by-id")]
        public async Task<IActionResult> GetItemByIdAsync(int id)
        {
            var result = await _usersRepository.GetByIdAsync(id);
            return Ok(result);
        }

        [HttpPost]
        [Route("save")]
        public async Task<IActionResult> SaveAsync(Users newTodo)
        {
            var result = await _usersRepository.SaveAsync(newTodo);
            return Ok(result);
        }

        [HttpPost]
        [Route("update")]
        public async Task<IActionResult> UpdateAsync(Users updateTodo)
        {
            var result = await _usersRepository.UpdateAsync(updateTodo);
            return Ok(result);
        }

        [HttpDelete]
        [Route("delete")]
        public async Task<IActionResult> DeleteAsync(int id)
        {
            var result = await _usersRepository.DeleteAsync(id);
            return Ok(result);
        }
    }
}