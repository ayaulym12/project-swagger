﻿using ProjectX.Models;
using ProjectX.Repos;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace ProjectX.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class RegionsController : ControllerBase
    {
        private readonly IRegionsRepository _regionsRepository;
        public RegionsController(IRegionsRepository todosRepository)
        {
            _regionsRepository = todosRepository;
        }


        [HttpGet]
        [Route("get-all")]
        public async Task<IActionResult> GetAllAsync()
        {
            var result = await _regionsRepository.GetAllAsync();
            return Ok(result);
        }

        [HttpGet]
        [Route("get-by-id")]
        public async Task<IActionResult> GetItemByIdAsync(int id)
        {
            var result = await _regionsRepository.GetByIdAsync(id);
            return Ok(result);
        }

        [HttpPost]
        [Route("save")]
        public async Task<IActionResult> SaveAsync(Regions newTodo)
        {
            var result = await _regionsRepository.SaveAsync(newTodo);
            return Ok(result);
        }

        [HttpPost]
        [Route("update")]
        public async Task<IActionResult> UpdateAsync(Regions updateTodo)
        {
            var result = await _regionsRepository.UpdateAsync(updateTodo);
            return Ok(result);
        }

        [HttpDelete]
        [Route("delete")]
        public async Task<IActionResult> DeleteAsync(int id)
        {
            var result = await _regionsRepository.DeleteAsync(id);
            return Ok(result);
        }
    }
}