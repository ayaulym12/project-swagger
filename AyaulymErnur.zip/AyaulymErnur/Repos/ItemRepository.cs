﻿using ProjectX.Models;
using Dapper;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectX.Repos
{
    public class ItemsRepository : IItemsRepository
    {
        private string myWorldDbConnection = string.Empty;

        private IDbConnection Connection
        {
            get
            {
                return new SqlConnection(myWorldDbConnection);
            }
        }
        public ItemsRepository(IConfiguration configuration)
        {
            myWorldDbConnection = configuration.GetConnectionString("ProjectCon");
        }

        public async Task<List<Items>> GetAllAsync()
        {
            using (IDbConnection conn = Connection)
            {
                string query = "SELECT * FROM Items";
                List<Items> todos = (await conn.QueryAsync<Items>(sql: query)).ToList();
                return todos;
            }
        }

        public async Task<Items> GetByIdAsync(int id)
        {
            using (IDbConnection conn = Connection)
            {
                string query = "SELECT * FROM Items WHERE Id = @id";
                Items todo = await conn.QueryFirstOrDefaultAsync<Items>(sql: query, param: new { id });
                return todo;
            }
        }

        public async Task<int> SaveAsync(Items newTodo)
        {
            using (IDbConnection conn = Connection)
            {
                string command = @"
    				INSERT INTO Items(Status, Name, Description, Price, Count)
    				VALUES(@Status, @Name, @Description, @Price, @Count)";

                var result = await conn.ExecuteAsync(sql: command, param: newTodo);
                return result;
            }
        }

        public async Task<int> UpdateAsync(Items updateTodo)
        {
            using (IDbConnection conn = Connection)
            {
                string command = @"
    		UPDATE Items SET Status = @Status, Name = @Name, Description = @Description, Price = @Price, Count = @Count 
                               WHERE Id = @Id";

                var result = await conn.ExecuteAsync(sql: command, param: updateTodo);
                return result;
            }
        }

        public async Task<int> DeleteAsync(int id)
        {
            using (IDbConnection conn = Connection)
            {
                string command = @"DELETE FROM Items WHERE Id = @id";
                var result = await conn.ExecuteAsync(sql: command, param: new { id });
                return result;
            }
        }
    }
}
