﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ProjectX.Models;

namespace ProjectX.Repos
{
    public interface IRegionsRepository
    {
        Task<List<Regions>> GetAllAsync();
        Task<Regions> GetByIdAsync(int id);
        Task<int> SaveAsync(Regions newTodo);
        Task<int> UpdateAsync(Regions updateTodo);
        Task<int> DeleteAsync(int id);
    }
}
