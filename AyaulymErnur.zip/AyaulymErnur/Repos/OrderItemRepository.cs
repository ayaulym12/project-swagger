﻿using ProjectX.Models;
using Dapper;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectX.Repos
{
    public class OrderItemsRepository : IOrderItemsRepository
    {
        private string myWorldDbConnection = string.Empty;

        private IDbConnection Connection
        {
            get
            {
                return new SqlConnection(myWorldDbConnection);
            }
        }
        public OrderItemsRepository(IConfiguration configuration)
        {
            myWorldDbConnection = configuration.GetConnectionString("ProjectCon");
        }

        public async Task<List<OrderItems>> GetAllAsync()
        {
            using (IDbConnection conn = Connection)
            {
                string query = "SELECT * FROM OrderItems";
                List<OrderItems> todos = (await conn.QueryAsync<OrderItems>(sql: query)).ToList();
                return todos;
            }
        }

        public async Task<OrderItems> GetByIdAsync(int id)
        {
            using (IDbConnection conn = Connection)
            {
                string query = "SELECT * FROM OrderItems WHERE Id = @id";
                OrderItems todo = await conn.QueryFirstOrDefaultAsync<OrderItems>(sql: query, param: new { id });
                return todo;
            }
        }

        public async Task<int> SaveAsync(OrderItems newTodo)
        {
            using (IDbConnection conn = Connection)
            {
                string command = @"
    				INSERT INTO Items(OrderId, ItemId)
    				VALUES(@OrderId, @ItemId)";

                var result = await conn.ExecuteAsync(sql: command, param: newTodo);
                return result;
            }
        }

        public async Task<int> UpdateAsync(OrderItems updateTodo)
        {
            using (IDbConnection conn = Connection)
            {
                string command = @"
    		UPDATE Items SET ItemId = @ItemId 
                               WHERE OrderId = @OrderId";

                var result = await conn.ExecuteAsync(sql: command, param: updateTodo);
                return result;
            }
        }

        public async Task<int> DeleteAsync(int id)
        {
            using (IDbConnection conn = Connection)
            {
                string command = @"DELETE FROM OrderItems WHERE OrderId = @id";
                var result = await conn.ExecuteAsync(sql: command, param: new { id });
                return result;
            }
        }
    }
}
