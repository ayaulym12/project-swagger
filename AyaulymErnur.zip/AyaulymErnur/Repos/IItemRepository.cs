﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ProjectX.Models;

namespace ProjectX.Repos
{
    public interface IItemsRepository
    {
        Task<List<Items>> GetAllAsync();
        Task<Items> GetByIdAsync(int id);
        Task<int> SaveAsync(Items newTodo);
        Task<int> UpdateAsync(Items updateTodo);
        Task<int> DeleteAsync(int id);
    }
}
