﻿using ProjectX.Models;
using Dapper;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectX.Repos
{
    public class OrdersRepository : IOrdersRepository
    {
        private string myWorldDbConnection = string.Empty;

        private IDbConnection Connection
        {
            get
            {
                return new SqlConnection(myWorldDbConnection);
            }
        }
        public OrdersRepository(IConfiguration configuration)
        {
            myWorldDbConnection = configuration.GetConnectionString("ProjectCon");
        }

        public async Task<List<Orders>> GetAllAsync()
        {
            using (IDbConnection conn = Connection)
            {
                string query = "SELECT * FROM Orders";
                List<Orders> todos = (await conn.QueryAsync<Orders>(sql: query)).ToList();
                return todos;
            }
        }

        public async Task<Orders> GetByIdAsync(int id)
        {
            using (IDbConnection conn = Connection)
            {
                string query = "SELECT * FROM Orders WHERE Id = @id";
                Orders todo = await conn.QueryFirstOrDefaultAsync<Orders>(sql: query, param: new { id });
                return todo;
            }
        }

        public async Task<int> SaveAsync(Orders newTodo)
        {
            using (IDbConnection conn = Connection)
            {
                string command = @"
    				INSERT INTO Orders(Status, UserId, RegionId, Sum,  CreatedTime)
    				VALUES(@Status, @UserId, @RegionId, @Sum, @CreatedTime)";

                var result = await conn.ExecuteAsync(sql: command, param: newTodo);
                return result;
            }
        }

        public async Task<int> UpdateAsync(Orders updateTodo)
        {
            using (IDbConnection conn = Connection)
            {
                string command = @"
    		UPDATE Orders SET Status = @Status, UserId = @UserId, RegionId = @RegionId, Sum = @Sum 
                               CreatedTime = @CreatedTime WHERE Id = @Id";

                var result = await conn.ExecuteAsync(sql: command, param: updateTodo);
                return result;
            }
        }

        public async Task<int> DeleteAsync(int id)
        {
            using (IDbConnection conn = Connection)
            {
                string command = @"DELETE FROM Orders WHERE Id = @id";
                var result = await conn.ExecuteAsync(sql: command, param: new { id });
                return result;
            }
        }
    }
}
