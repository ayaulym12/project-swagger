﻿using ProjectX.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ProjectX.Repos
{
    public interface IUsersRepository
    {
        Task<List<Users>> GetAllAsync();
        Task<Users> GetByIdAsync(int id);
        Task<int> SaveAsync(Users newTodo);
        Task<int> UpdateAsync(Users updateTodo);
        Task<int> DeleteAsync(int id);
    }
}
