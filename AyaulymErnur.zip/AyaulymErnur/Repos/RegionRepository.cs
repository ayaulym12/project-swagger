﻿using ProjectX.Models;
using Dapper;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectX.Repos
{
    public class RegionsRepository : IRegionsRepository
    {
        private string myWorldDbConnection = string.Empty;

        private IDbConnection Connection
        {
            get
            {
                return new SqlConnection(myWorldDbConnection);
            }
        }
        public RegionsRepository(IConfiguration configuration)
        {
            myWorldDbConnection = configuration.GetConnectionString("ProjectCon");
        }

        public async Task<List<Regions>> GetAllAsync()
        {
            using (IDbConnection conn = Connection)
            {
                string query = "SELECT * FROM Regions";
                List<Regions> todos = (await conn.QueryAsync<Regions>(sql: query)).ToList();
                return todos;
            }
        }

        public async Task<Regions> GetByIdAsync(int id)
        {
            using (IDbConnection conn = Connection)
            {
                string query = "SELECT * FROM Regions WHERE Id = @id";
                Regions todo = await conn.QueryFirstOrDefaultAsync<Regions>(sql: query, param: new { id });
                return todo;
            }
        }

        public async Task<int> SaveAsync(Regions newTodo)
        {
            using (IDbConnection conn = Connection)
            {
                string command = @"
    				INSERT INTO Regions(Status, Name, ParentId)
    				VALUES(@Status, @Name, @ParentId)";

                var result = await conn.ExecuteAsync(sql: command, param: newTodo);
                return result;
            }
        }

        public async Task<int> UpdateAsync(Regions updateTodo)
        {
            using (IDbConnection conn = Connection)
            {
                string command = @"
    		UPDATE Regions SET Status = @Status, Name = @Name, ParentId = @ParentId 
                               WHERE Id = @Id";

                var result = await conn.ExecuteAsync(sql: command, param: updateTodo);
                return result;
            }
        }

        public async Task<int> DeleteAsync(int id)
        {
            using (IDbConnection conn = Connection)
            {
                string command = @"DELETE FROM Regions WHERE Id = @id";
                var result = await conn.ExecuteAsync(sql: command, param: new { id });
                return result;
            }
        }
    }
}
