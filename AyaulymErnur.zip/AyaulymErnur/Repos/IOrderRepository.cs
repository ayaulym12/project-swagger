﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ProjectX.Models;

namespace ProjectX.Repos
{
    public interface IOrdersRepository
    {
        Task<List<Orders>> GetAllAsync();
        Task<Orders> GetByIdAsync(int id);
        Task<int> SaveAsync(Orders newTodo);
        Task<int> UpdateAsync(Orders updateTodo);
        Task<int> DeleteAsync(int id);
    }
}
