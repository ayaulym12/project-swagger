﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ProjectX.Models;

namespace ProjectX.Repos
{
    public interface IOrderItemsRepository
    {
        Task<List<OrderItems>> GetAllAsync();
        Task<OrderItems> GetByIdAsync(int id);
        Task<int> SaveAsync(OrderItems newTodo);
        Task<int> UpdateAsync(OrderItems updateTodo);
        Task<int> DeleteAsync(int id);
    }
}
