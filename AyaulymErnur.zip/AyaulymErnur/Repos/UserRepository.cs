﻿using ProjectX.Models;
using Dapper;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectX.Repos
{
    public class UsersRepository : IUsersRepository
    {
        private string myWorldDbConnection = string.Empty;

        private IDbConnection Connection
        {
            get
            {
                return new SqlConnection(myWorldDbConnection);
            }
        }
        public UsersRepository(IConfiguration configuration)
        {
            myWorldDbConnection = configuration.GetConnectionString("ProjectCon");
        }

        public async Task<List<Users>> GetAllAsync()
        {
            using (IDbConnection conn = Connection)
            {
                string query = "SELECT * FROM Users";
                List<Users> todos = (await conn.QueryAsync<Users>(sql: query)).ToList();
                return todos;
            }
        }

        public async Task<Users> GetByIdAsync(int id)
        {
            using (IDbConnection conn = Connection)
            {
                string query = "SELECT * FROM Users WHERE Id = @id";
                Users todo = await conn.QueryFirstOrDefaultAsync<Users>(sql: query, param: new { id });
                return todo;
            }
        }

        public async Task<int> SaveAsync(Users newTodo)
        {
            using (IDbConnection conn = Connection)
            {
                string command = @"
    				INSERT INTO Users(Status, Login, Password, FirstName, LastName, Role)
    				VALUES(@Status, @Login, @Password, @FirstName, @LastName, @Role)";

                var result = await conn.ExecuteAsync(sql: command, param: newTodo);
                return result;
            }
        }

        public async Task<int> UpdateAsync(Users updateTodo)
        {
            using (IDbConnection conn = Connection)
            {
                string command = @"
    		UPDATE Users SET Status = @Status, Login = @Login, Password = @Password, FirstName = @FirstName,
                            LastName = @Lastname, Role = @Role WHERE Id = @Id";

                var result = await conn.ExecuteAsync(sql: command, param: updateTodo);
                return result;
            }
        }

        public async Task<int> DeleteAsync(int id)
        {
            using (IDbConnection conn = Connection)
            {
                string command = @"DELETE FROM Users WHERE Id = @id";
                var result = await conn.ExecuteAsync(sql: command, param: new { id });
                return result;
            }
        }
    }
}
